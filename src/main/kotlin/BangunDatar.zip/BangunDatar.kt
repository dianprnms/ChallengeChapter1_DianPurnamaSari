package oop_solid

open class BangunDatar {
    open fun jenisBangunDatar(jenis : String){
        println("Jenis Bangun Datar : $jenis")
    }

    open fun sgtg(){
    }

    open fun tambah() {

    }

}
